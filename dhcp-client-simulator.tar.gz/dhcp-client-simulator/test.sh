number=123
n1=${number:0:2}
n2=${number:2:1}
echo $n1
echo $n2
