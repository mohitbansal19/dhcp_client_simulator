#!/bin/bash
# Function to generate a random hexadecimal digit (0-9, A-F)

function random_hex_digit() {
	echo $((RANDOM % 16))
}

# Function to generate a random MAC address
function generate_random_mac() {
	mac=""
	for ((i = 0; i < 6; i++)); do
		# Generate two random hexadecimal digits and concatenate them with a colon
		hex_digit=$(printf "%x%x" $(random_hex_digit) $(random_hex_digit))
		mac+=$(echo $hex_digit | tr '[:lower:]' '[:upper:]')
		if [ $i -lt 5 ]; then
			mac+=":"
		fi
	done
	echo "$mac"
}

for n in {1..400}
do
	mac_address=$(generate_random_mac)
	echo "$n. $mac_address"
	./dhtest -m $mac_address -i eth4       
done
